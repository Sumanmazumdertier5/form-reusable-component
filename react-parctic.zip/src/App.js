// import logo from './logo.svg';
import './App.css';
import React from 'react';
import Main from "./main/main";
// import Router from "./router/Router";


function App() {
  return (
    <>
      <Main />
    </>
  );
}

export default App;
