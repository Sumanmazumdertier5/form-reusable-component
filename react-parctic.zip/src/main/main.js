import React, { useState } from 'react';
import SidePanel from "../router/sidePanel"
// import Router from "../router/router";
import { BrowserRouter, Route, Routes, Link } from "react-router-dom";
import Form from "../form/form";
import Notification from "../notification/notification";
import Router from "../router/router";
const Main = () => {

    return (
        <React.Fragment>
            <div className='left'>
                <SidePanel />
            </div>
            {/* <div style="width:80%; float:right"> */}
            <Router />
            {/* </div> */}
        </React.Fragment>
    )
}
export default Main;