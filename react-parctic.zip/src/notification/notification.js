import React, { useState } from 'react';

const Notification = ()=>{

    return(
        <React.Fragment>
            <h2>Notifivication</h2>
        </React.Fragment>
    )
}
export default Notification;
