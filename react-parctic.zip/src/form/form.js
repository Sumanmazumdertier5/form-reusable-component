import React, { useState } from 'react';

const Form = ()=>{
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [formError, setFormError] = useState({
        name: '',
        email: '',
    })
    const handelerSubmit = (e)=>{
        e.preventDefault();
        if(name === ''){
            setFormError({
                ...formError,
                name: "Please enter your name"
            })
        }
    }

    return(
        <React.Fragment>
            <h1>Form</h1>
            <form>
                <div className='form-group'>
                    <input type="text" onChange={name} placeholder="Enter user name"/>
                </div>
                <p>{formError.name}</p>
                <div className='form-group'>
                    <input type="text" onChange={email} placeholder="Enter email"/>
                </div>
                <button onClick={handelerSubmit}>Submit</button>
            </form>
        </React.Fragment>
    )
}
export default Form